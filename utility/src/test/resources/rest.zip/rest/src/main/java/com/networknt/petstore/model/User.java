
package com.networknt.petstore.model;
import java.io.Serializable;

public class User implements Serializable {
    public User () {
    }
}
