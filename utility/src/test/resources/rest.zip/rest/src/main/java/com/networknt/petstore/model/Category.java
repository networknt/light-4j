
package com.networknt.petstore.model;
import java.io.Serializable;

public class Category implements Serializable {
    public Category () {
    }
}
