
package com.networknt.petstore.model;
import java.io.Serializable;

public class Tag implements Serializable {
    public Tag () {
    }
}
