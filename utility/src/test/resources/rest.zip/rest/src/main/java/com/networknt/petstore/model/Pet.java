
package com.networknt.petstore.model;
import java.io.Serializable;

public class Pet implements Serializable {
    public Pet () {
    }
}
