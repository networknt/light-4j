
package com.networknt.petstore.model;
import java.io.Serializable;

public class ApiResponse implements Serializable {
    public ApiResponse () {
    }
}
