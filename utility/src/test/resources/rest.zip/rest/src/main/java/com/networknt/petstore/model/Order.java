
package com.networknt.petstore.model;
import java.io.Serializable;

public class Order implements Serializable {
    public Order () {
    }
}
